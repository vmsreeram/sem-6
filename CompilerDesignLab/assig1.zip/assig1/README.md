# Assignment 1

## How to run
```bash
make
./a.out
```
## clean 
```bash
make clean
```